import React, { useRef, useEffect, useCallback } from 'react';
import { PhysicsWorldState, ThemeMode } from '../game/types';
import { renderGame } from '../game/renderer';
import { updatePhysics, sampleShakeOffset } from '../game/physics';
import { PERF } from '../game/perf';

interface GameCanvasProps {
  worldState: PhysicsWorldState;
  arenaWidth: number;
  arenaHeight: number;
  theme: ThemeMode;
  onRotateStep: (delta: number) => void;
  onNudgeBall: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  worldState,
  arenaWidth,
  arenaHeight,
  theme,
  onRotateStep,
  onNudgeBall
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const lastTimeRef = useRef<number>(performance.now());
  const visualRotationRef = useRef<number>(worldState.gravityAngle);

  // Swipe gesture tracking
  const touchStartPos = useRef<{ x: number; y: number } | null>(null);

  // Reset the camera interpolation whenever a new world (level/replay) is
  // mounted — otherwise the camera eases from the previous level's accumulated
  // angle while physics already runs at the new gravity angle.
  useEffect(() => {
    visualRotationRef.current = worldState.gravityAngle;
  }, [worldState]);

  // Render & physics loop
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d', { alpha: false });
    if (!ctx) return;

    let isMounted = true;
    lastTimeRef.current = performance.now();

    const loop = (now: number) => {
      if (!isMounted) return;

      const rawDt = (now - lastTimeRef.current) / 1000;
      lastTimeRef.current = now;

      // Clamp delta time to avoid spiral of death on tab unfocus
      const dt = Math.min(rawDt, 0.05);

      // 1. Update Physics
      updatePhysics(worldState, dt, arenaWidth, arenaHeight);

      // 2. Smooth Visual Camera Rotation Interpolation
      // Handle angle wrapping correctly for shortest rotation path.
      // The PHYSICS angle itself already eases toward the player-intended
      // target (physics.ts GRAVITY_EASE_RATE), so the camera only needs to
      // hug it tightly — one smoothing layer owns the feel, not two.
      let diff = worldState.gravityAngle - visualRotationRef.current;
      while (diff < -Math.PI) diff += Math.PI * 2;
      while (diff > Math.PI) diff -= Math.PI * 2;
      visualRotationRef.current += diff * (1 - Math.exp(-dt * 30));

      // 3. Render Canvas (DPR capped by perf tier to protect fill-rate)
      const dpr = Math.min(window.devicePixelRatio || 1, PERF.maxDpr);
      const width = canvas.width / dpr;
      const height = canvas.height / dpr;

      ctx.save();
      ctx.scale(dpr, dpr);

      renderGame(
        {
          ctx,
          width,
          height,
          theme,
          visualRotation: visualRotationRef.current,
          ...sampleShakeOffset(worldState.shake)
        },
        worldState,
        arenaWidth,
        arenaHeight
      );

      ctx.restore();

      animFrameRef.current = requestAnimationFrame(loop);
    };

    animFrameRef.current = requestAnimationFrame(loop);

    return () => {
      isMounted = false;
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [worldState, arenaWidth, arenaHeight, theme]);

  // Handle Resize & DPI Scaling
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    let dprMedia: MediaQueryList | null = null;
    let dprMediaHandler: (() => void) | null = null;

    const handleResize = () => {
      const parent = canvas.parentElement;
      if (!parent) return;

      const dpr = Math.min(window.devicePixelRatio || 1, PERF.maxDpr);
      const width = parent.clientWidth;
      const height = parent.clientHeight;

      canvas.width = width * dpr;
      canvas.height = height * dpr;
      canvas.style.width = `${width}px`;
      canvas.style.height = `${height}px`;

      // Re-fit the backing store when the window moves to a display with a
      // different devicePixelRatio (ResizeObserver alone won't fire for that).
      if (dprMedia && dprMediaHandler) {
        dprMedia.removeEventListener('change', dprMediaHandler);
      }
      if (typeof window.matchMedia === 'function') {
        dprMedia = window.matchMedia(`(resolution: ${window.devicePixelRatio || 1}dppx)`);
        dprMediaHandler = handleResize;
        dprMedia.addEventListener('change', dprMediaHandler);
      }
    };

    handleResize();
    const observer = new ResizeObserver(handleResize);
    if (canvas.parentElement) {
      observer.observe(canvas.parentElement);
    }

    return () => {
      observer.disconnect();
      if (dprMedia && dprMediaHandler) {
        dprMedia.removeEventListener('change', dprMediaHandler);
      }
    };
  }, []);

  // Touch Swipe Gesture for quick 90° gravity rotation on canvas
  const handleTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 1) {
      touchStartPos.current = {
        x: e.touches[0].clientX,
        y: e.touches[0].clientY
      };
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartPos.current || e.changedTouches.length === 0) return;

    const dx = e.changedTouches[0].clientX - touchStartPos.current.x;
    const dy = e.changedTouches[0].clientY - touchStartPos.current.y;
    const dist = Math.hypot(dx, dy);

    if (dist > 45) {
      if (Math.abs(dx) > Math.abs(dy)) {
        // Horizontal swipe -> 90° rotation
        if (dx > 0) {
          onRotateStep(Math.PI / 2); // Swipe right -> Clockwise
        } else {
          onRotateStep(-Math.PI / 2); // Swipe left -> Counter-clockwise
        }
      } else if (dy > 0) {
        // Swipe DOWN -> 180° gravity flip. This is the single most
        // destructive accidental gesture (instant reversal mid-transit),
        // so it demands a deliberate long, unambiguous vertical stroke —
        // well beyond the 45px rotate threshold and clearly steeper
        // than 45° — before the game commits to it.
        if (dist > 90 && Math.abs(dy) > Math.abs(dx) * 1.4) {
          onRotateStep(Math.PI);
        }
      } else {
        // Swipe up -> nudge
        onNudgeBall();
      }
    } else {
      // Tap on canvas nudges ball
      onNudgeBall();
    }

    // Prevent the browser's synthetic click from firing after the handled
    // touch — otherwise taps trigger TWO nudges (touchend + click).
    e.preventDefault();

    touchStartPos.current = null;
  };

  return (
    <div
      className="relative w-full h-full flex items-center justify-center overflow-hidden cursor-crosshair"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      onClick={() => onNudgeBall()}
    >
      <canvas ref={canvasRef} className="block w-full h-full select-none touch-none" />
    </div>
  );
};
